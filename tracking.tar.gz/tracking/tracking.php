<?php 
	header("Content-Type: text/event-stream");
	header("Cache-Control: no-cache");
	header("Connection: keep-alive");
	include('connection.php');
	ini_set('session.cookie_domain', '.vinam.in');
	if(session_id() == '') {
	    session_start();
	} 
	$query 								=	'';
	if(isset($_GET['parm'])) { 
		$stored_values 						= 	$_GET['parm'];  
		$decode_input 						=	json_decode($stored_values);    print_r($decode_input);
		$track_input['host']				=	$decode_input->h;
		$track_input['browser']				=	$decode_input->b;
		$m_details 							=	$decode_input->uid;
		$track_input['userid'] 				=	0;
		if(isset($decode_input->uid) && $decode_input->uid != '') {
	 		$m_details_arr 					=	explode('_', $m_details);
			$track_input['userid']			=	intval($m_details_arr[0]);
			/*if(isset($m_details_arr[1]))
			$track_input['campaign_id']	=	intval($m_details_arr[1]);
			else*/
			//$track_input['campaign_id']=	0;
		}
		$track_input['campaign_id'] 	=	0;
		if($track_input['userid'] =='0') {
			if(!isset($_SESSION["userid"])&& $_SESSION["userid"]=="") { 
				$track_input['userid'] 		=	generateRandomString(5);
				$_SESSION["userid"] 		=	$track_input['userid'];
			}
			else {
				$track_input['userid'] 		=	$_SESSION["userid"];
			}
			$track_input['campaign_id']		=	0;
		}
		$track_input['ip']					=	getip();
		$track_input['url']					=	$decode_input->u;
		$track_input['browser_language'] 	=	$decode_input->bl;
		if(isset($decode_input->o))
			$track_input['os'] 					=	$decode_input->o;
		$track_input['screen_resolution'] 	=	$decode_input->res;
		$valid_inputs 						=	validate_entry($track_input);
		$details_arr 						=	array();
		if(!empty($valid_inputs)) { 
			$valid_inputs['date']				=	date('Y-m-d H:i:s');
			include_once("geoip.inc");
			$ip									=	$track_input['ip'];
			include_once("geoipcity.inc");
		  	require_once 'geoipregionvars.php';
		  	global $GEOIP_REGION_NAME;
		  	$gi                   				= 	geoip_open("GeoLiteCity.dat",GEOIP_STANDARD);
		  	$full_country_record  	 			= 	geoip_record_by_addr($gi, $ip);
		  	$country              				= 	$full_country_record->country_code;
		 	$city           					= 	$full_country_record->city;
		 	$valid_inputs['country']			= 	$country;	

		 	$check_linkexist 					=	"SELECT * FROM tracking_links where url='".$valid_inputs['url']."'"; 				
			$res_links 							=	query($check_linkexist);
			$check_linkresult 					=	fetch_array($res_links);
			if(empty($check_linkresult)) {
				$link_arr 						=	array();
				$link_arr['url']				=	$valid_inputs['url'];
				$link_arr['date_created'] 	=	date('Y-m-d H:i:s');

				$sql 							=	'INSERT INTO tracking_links (';
				$track_keys						='';$track_values='';
				foreach ($link_arr as $key => $value) {
					$track_keys 				.=	$key.',';
					$track_values 				.=	'"'.$value.'",';
				}
				$track_keys 					=	substr($track_keys, 0,-1);
				$track_values 					=	substr($track_values, 0,-1);
				$sql 							.= 	$track_keys.') VALUES ('.$track_values.')';  
				query($sql);
				$valid_inputs['url'] 			=	insert_id();
			} else {
				$valid_inputs['url'] 			=	$check_linkresult['id'];
			}


			//check already clicked the link
			echo $check_exist 						=	"SELECT * FROM tracking where 	ip='".$valid_inputs['ip']."'  and url='".$valid_inputs['url']."' and browser='".$valid_inputs['browser']."' and date(date) ='".date('Y-m-d')."'"; 				
			$res 								=	query($check_exist);
			$check_result 						=	fetch_array($res);
			if(empty($check_result))  {
				echo $check_user_visited 			=	"SELECT * FROM tracking where ip='".$track_input['ip']."' and url=".$valid_inputs['url'];				
				$res 							=	query($check_user_visited);
				$check_userresult 				=	fetch_array($res);
				if(!empty($check_userresult)) {
					$valid_inputs['userid'] 	=	$check_userresult['userid'];
				}
				$sql 							=	'INSERT INTO tracking (';
				$track_keys						='';$track_values='';
				foreach ($valid_inputs as $key => $value) {
					$track_keys 				.=	$key.',';
					$track_values 				.=	'"'.$value.'",';
				}
				$track_keys 					=	substr($track_keys, 0,-1);
				$track_values 					=	substr($track_values, 0,-1);
				$sql 							.= 	$track_keys.') VALUES ('.$track_values.')';  
				query($sql);
				$details_arr['track_id']		=	insert_id();
				
			
			} else {
				$details_arr['track_id']		=	$check_result['id'];
				/*$sql 							=	'UPDATE tracking set viewed_count=viewed_count+1 where id='.$check_result['id'];
				query($sql);*/
			}
			if(isset($decode_input->el) && $decode_input->el !="") {
				$details_arr['view_date'] 		=	date('Y-m-d H:i:s');
				$details_arr['coorinate']		=	$decode_input->pos;
				$cord_array 					=	explode('X', $details_arr['coorinate']);
				$details_arr['x_cordinate'] 	=	$decode_input->x;
				$details_arr['y_cordinate'] 	=	$decode_input->y;
				
				//$check_detailsexist 				=	"SELECT * FROM tracking_details where (track_id='".$details_arr['track_id']."'  and element='".$decode_input->el."') or (track_id='".$details_arr['track_id']."' and  view_date ='".$details_arr['view_date']."' )"; 
				echo $check_detailsexist 				=	"SELECT * FROM tracking_details where (track_id='".$details_arr['track_id']."'  and 	coorinate='".$details_arr['coorinate']."'and   view_date like'".date('Y-m-d H:i')."%' )"; 	
				//$check_detailsexist 				=	"SELECT * FROM tracking_details where (track_id='".$details_arr['track_id']."'  and 	coorinate='".$details_arr['coorinate']."') or (track_id='".$details_arr['track_id']."' and  view_date like'".date('Y-m-d H:i')."%' )"; 	
				$res 								=	query($check_detailsexist);
				$check_detailsresult 				=	fetch_array($res);
				//sleep(10);
				if(empty($check_detailsresult) ) {

					$details_arr['element']			=	trim($decode_input->el);
					
					if(isset($decode_input->rf))
						$details_arr['referer']		=	$decode_input->rf;
					
					$sql 							=	"INSERT INTO tracking_details (";
					$track_keys						='';$track_values='';
					foreach ($details_arr as $key => $value) {
						$track_keys 				.=	$key.",";
						$track_values 				.=	"'".$value."',";
					}
					$track_keys 					 =	substr($track_keys, 0,-1);
					$track_values 					 =	substr($track_values, 0,-1);
					$sql 							.= 	$track_keys.") VALUES (".$track_values.")";  
					query($sql);
				}
			}
			
		}
	}
	echo 'success';
	function getip() 
	{
		if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        	$ipaddress 		= $_SERVER['HTTP_CLIENT_IP'];
		} else if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	        $ipaddress 		= $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else if(isset($_SERVER['HTTP_X_FORWARDED'])) {
	        $ipaddress	 	= $_SERVER['HTTP_X_FORWARDED'];
		} else if(isset($_SERVER['HTTP_FORWARDED_FOR'])) {
	        $ipaddress 		= $_SERVER['HTTP_FORWARDED_FOR'];
		} else if(isset($_SERVER['HTTP_FORWARDED'])){
	        $ipaddress 		= $_SERVER['HTTP_FORWARDED'];
		} else if(isset($_SERVER['REMOTE_ADDR'])) {
	        $ipaddress 		= $_SERVER['REMOTE_ADDR'];
		} else {
	        $ipaddress 		= 'UNKNOWN';
		}
	    return  $ipaddress;
	}
	function validate_entry($track_input)
	{
		$error 			=	0;
		$clean_arr 		=	array();
		if(!empty($track_input)) {
			foreach ($track_input as $key => $value) {
				switch ($key) {
					case 'url' :
							if (!filter_var(trim($value), FILTER_VALIDATE_URL) === false) {
							    $clean_arr[$key] 	=	trim($value);
							} else {
							    $error++;
							}
						break;
					case 'ip':
							if (!filter_var(trim($value), FILTER_VALIDATE_IP) === false) {
							    $clean_arr[$key] 	=	trim($value);
							} else {
							    $error++;
							}
						break;
					case 'host':
					case 'os':
					case 'browser_language':
					case 'browser':
					case  'screen_resolution':
					case 'userid':
							if (trim($value)) {
							    $clean_arr[$key] 	=	trim($value);
							} 
						break;
					case 'campaign_id':
					
							if(is_numeric(trim($value))) {
								$clean_arr[$key] 	=	trim($value);
							} else {
								$error++;
							}

					default:
						# code...
						break;
				}
			}
		}
		if($error == 0) {
			return $clean_arr;
		} else {
			return array();
		}
		
	}
	function generateRandomString($length = 10) 
	{
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) 
	    {
	      $randomString .= $characters[rand(0, strlen($characters) - 1)];
	    }
	    return $randomString;
	}
	function getInbetweenStrings($start, $end, $str) {
        $unmatchArray           = array();
        $matches                = array();
        $regex                  = "/$start([a-zA-Z0-9_]*)$end/";
        preg_match_all($regex, $str, $matches);

        foreach ($matches[1] as $key => $value) {
            $check_tok          = substr($value, 7);
           	$unmatchArray[] = $value;
        }
        return $unmatchArray;
    }
?>
