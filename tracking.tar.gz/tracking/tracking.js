(function() { 

	
	var M 					= 	document;
   	var N 					= 	navigator;
   	var O 					=	window;
   	var tar_arr				=	{};
   	tar_arr['h']			=	h();
    tar_arr['b'] 			=	bn();
  	tar_arr['uid']			=	gc('userid');
    tar_arr['bl']			=	bl();
    tar_arr['u']			=	cu();
   	tar_arr['o'] 			=	os();
    tar_arr['res'] 			=	res();
    tar_arr['rf'] 			= 	""; 
   	var  newarr				=	{};  
   	O.addEventListener('load', function(){ 
 
    M.addEventListener('touchstart', function(e){
    	var nr				=	{};
      	nr['h']				=	h();
	    nr['b'] 			=	bn();
	  	nr['uid']			=	gc('userid');
	    nr['bl']			=	bl();
	    nr['u']				=	cu();
	   	nr['o'] 			=	mos();
	    nr['res'] 			=	res();
	    nr['rf'] 			= ""; 
       	nr['pos'] 			= 	e.changedTouches[0].pageX +' X '+e.changedTouches[0].pageY; 
       	nr['x'] 			=	e.changedTouches[0].pageX;
	    nr['y'] 			=	e.changedTouches[0].pageY;
	    nr['el'] 			=	'<div class="ssss"></div>';
	    var dt 				=	encd(nr);  
	   	var ajurl 	=	lk(); 
	     var xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
		    if (xhttp.readyState == 4 && xhttp.status == 200) {
		      //alert(xhttp.responseText);
		    }
		  }
		  xhttp.open("GET", ajurl+dt, true);
		  xhttp.send();
       
    }, false)
    M.addEventListener('touchmove', function(e){
    	var nr				=	{};
       	nr['h']				=	h();
	    nr['b'] 			=	bn();
	  	nr['uid']			=	gc('userid');
	    nr['bl']			=	bl();
	    nr['u']				=	cu();
	   	nr['o'] 			=	mos();
	    nr['res'] 			=	res();
	    nr['rf'] 			= ""; 
       	nr['pos'] 			= 	e.changedTouches[0].pageX +' X '+e.changedTouches[0].pageY; 
       	nr['x'] 			=	e.changedTouches[0].pageX;
	    nr['y'] 			=	e.changedTouches[0].pageY;
	    nr['el'] 			=	'<div class="ssss"></div>';
	    var dt 				=	encd(nr);  
	    //aj(dt);
	    var ajurl 	=	lk(); 
	     var xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
		    if (xhttp.readyState == 4 && xhttp.status == 200) {
		      //alert(xhttp.responseText);
		    }
		  }
		  xhttp.open("GET", ajurl+dt, true);
		  xhttp.send();
       
    }, false)

 
}, false)

   	M.addEventListener('mousedown', function (e) {   
   		e.preventDefault();  
   		if(e.target.nodeName=='A' && e.which ==1) {
   			tar_arr['u']		=	e.target.href;
    		sd(tar_arr);
    		if(e.which ==1)
				st(url);
   		}
   	});
  	M.querySelector('img').addEventListener('mousedown', function (e) {  
		e.preventDefault();
		tar_arr['u']			=	this.parentNode.href; 
    	sd(tar_arr);
    	
	});
	function lk() {
		var l 	=	"http://localhost/retarget/target.php?parm=";
		return l;
	}
  	O.setInterval(function(){
	  tH('div','mouseenter');
	  
	
	}, 1000);
  	function st(url) {
  		setTimeout(function() {  
		  window.location = url;
		 }, 3000);
  	}
	
	
    function el(ret) { 
    	tar_arr['el']			=	ret['el'];
    	tar_arr['pos']			=	ret['po'];
    	tar_arr['x']			=	ret['x'];
    	tar_arr['y']			=	ret['y'];
		sd(tar_arr);
    }
	function h(){
    	var a 				= M.location.hostname;
		return a;
    }  
    function bn() {
		var nAgt 	=	nu();
		var no,vo,ix;
		if ((vo 	= nAgt.indexOf("OPR/"))!=-1) {
			b 	= "Opera";
		 	fv 	= nAgt.substring(vo+4);
		} else if ((vo=nAgt.indexOf("Opera"))!=-1) {
		 	b 	= "Opera";
		 	fv 	= nAgt.substring(vo+6);
		 	if ((vo = nAgt.indexOf("Version"))!=-1) 
		   		fv = nAgt.substring(vo+8);
		} else if ((vo=nAgt.indexOf("MSIE"))!=-1) {
		 	b 	= "Microsoft Internet Explorer";
		 	fv 	= nAgt.substring(vo+5);
		} else if ((vo=nAgt.indexOf("Chrome"))!=-1) {
		 	b 	= "Chrome";
		 	fv 	= nAgt.substring(vo+7);
		} else if ((vo=nAgt.indexOf("Safari"))!=-1) {
		 	b 	= "Safari";
		 	fv 	= nAgt.substring(vo+7);
		 	if ((vo = nAgt.indexOf("Version"))!=-1) 
		   		fv = nAgt.substring(vo+8);
		} else if ((vo=nAgt.indexOf("Firefox"))!=-1) {
		 	b 	= "Firefox";
		 	fv 	= nAgt.substring(vo+8);
		} else if ( (no=nAgt.lastIndexOf(' ')+1) < 
		          (vo=nAgt.lastIndexOf('/')) ) {
		 	b 	= nAgt.substring(no,vo);
		 	fv 	= nAgt.substring(vo+1);
		 	if (b.toLowerCase()==b.toUpperCase()) {
		  		b = N.appName;
		 	}
		}
		if ((ix=fv.indexOf(";"))!=-1)
		   fv 		=	fv.substring(0,ix);
		if ((ix = fv.indexOf(" "))!=-1)
		   fv 		=	fv.substring(0,ix);

		majorVersion 		= parseInt(''+fv,10);
		if (isNaN(majorVersion)) {
		 	fv  	= ''+parseFloat(N.appVersion); 
		 	majorVersion 	= parseInt(N.appVersion,10);
		}
		return b+" "+fv;
	}
	function  os() {
		if(N.oscpu !="")
			return N.oscpu;
		else {
			return mos();
		}
	}
	function mos() {
	  	var userAgent = N.userAgent || N.vendor || O.opera;
		if( userAgent.match( /iPad/i ) || userAgent.match( /iPhone/i ) || userAgent.match( /iPod/i ) ){
	    	return 'iOS';
		} else if( userAgent.match( /Android/i ) ){
			return 'Android';
	  	} else {
	    	return 'unknown';
	  	}
	}
	function bl() {
		var l 	=	N.language;
		return l;
	}
    function gc(cname) {
	    var name 	= cname + "=";
	    var ca 		= M.cookie.split(';');
	    for(var i=0; i<ca.length; i++) {
	        var c 	= ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1);
	        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
	    }
	    return "";
	} 
	function nu() {
		var nAgt 			= N.userAgent;
		return nAgt;
	}
    function aj(data) { 
    	var ajurl 	=	lk();
    	var d = O.XMLHttpRequest;
        if (!d) return !1;
        var e = new d;
        if (!("withCredentials" in e)) return !1;
        e.open("GET", ajurl+data, true);
        e.withCredentials = !0;
        e.setRequestHeader("Content-Type", "text/plain");
        e.onreadystatechange = function() {
            4 == e.readyState
        };
        e.send();
        return !0
    }
    function res() {
    	var w 	=	O.screen.availHeight;
    	var h 	=	O.screen.availWidth;
    	return w+'X'+h;
    }
    function cu(a) {
    	var u 	=	O.location.href; 
    	return u;
    }
    function rad() { 
    	alert('check');
    }  
    function s(cnam,cval) { 
    	var d = new Date();
    	d.setTime(d.getTime() + (3600 * 1000 * 24 * 365 * 10));
    	var expires = "expires="+d.toUTCString();
    	var dom 	=	'vinam.in';
    	M.cookie = cnam + "=" + cval + "; " + expires+";path=/;domain="+dom+";"; 
    	
    }
    
    O.onload = function sse() {   
    	var na 					=	 encd(tar_arr); 
    	if (!!O.EventSource) {
			var tar_link 		=	lk()+na; 
			var source 			= new EventSource(tar_link, { withCredentials: false } ); 
			source.addEventListener("message", function(e) { 
			}, false);
			source.addEventListener("open", function(e) { 
				
			}, false);
			source.addEventListener("error", function(e) { 
				source.close();
			}, false);
		} 
	} 
	function sd(newarr) {  
		var pa 					=	encd(newarr);  
		var tar_link 			=	lk()+pa;  
		N.sendBeacon(tar_link, newarr);
	}
	var pk=function(){ //alert('dfsf');
		return 'check';
	}
	function track_h(selector,time) { 
		 var elements = O.document.querySelectorAll(selector);
	}
	function encd(na) {
		var na 					=	JSON.stringify(na);
		return na;
	}
	
	function tH(selector, ev) {
	    var timeoutId;
	    var track_arr={};
	    var elements = O.document.querySelectorAll(selector);
	  	if(elements) { 
	    	for (var i = 0; i < elements.length; i++) {
		    	elements[i].addEventListener(ev, function(e) { 
				    var te = e.target || e.srcElement;
				    var classes = te.className;
				    var id = te.id;
				    var ret ='<'+selector+' class="'+classes+'" id="'+id+'"';
				    if(selector == 'img')
				    	var ret = ret+' src="'+te.src+'"'; 
				    else if(selector == 'a')
				    	var ret = ret +' href="'+te.href+'"';
				   	ret =ret+'>'; 
				    track_arr['el'] =ret; 
				    var ele = e.target.outerHTML; 
				    var testRE = ele.match("<(.*)>"); //console.log(e.target.outerHTML);
					//alert(testRE[0]);
				    track_arr['el'] =testRE[0]; 
				    track_arr['po']=e.pageX+"X"+e.pageY; //alert(track_arr['po']);
				    track_arr['x']=e.pageX;
				    track_arr['y']=e.pageY;
				   	el(track_arr);
				    
			    });
	    	}
		}   
	    	
	}
	function rf() {
		var x = M.referrer;
		if (/^https?:\/\//i.test(x)) {
			return x;
		} else if (/^http?:\/\//i.test(x)) {
			return x;
		} else {
			if(x !='')
				x = "http"+x;
			return x;
		}
	}
	function up() {
		var p = M.location.protocol; alert(p);
		return p;
	}
	function me(num) {
		var t 	=	'';
		if(num==1) t='left';
		else if(num==2) t='middle';
		else if(num==3) t='right';
		return t;
	}
	
	
})();

function tc(appid){  
   //	tar_arr['u'] = appid;
   	alert(appid);
}
